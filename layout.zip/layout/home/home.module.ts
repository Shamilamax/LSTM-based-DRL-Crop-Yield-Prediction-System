import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { PageHeaderModule } from '../../shared';

import { homeRoutingModule } from './home-routing.module';
import { homeComponent } from './home.component';

@NgModule({
    imports: [CommonModule, homeRoutingModule, PageHeaderModule],
    declarations: [homeComponent]
})
export class HomeModule {}
