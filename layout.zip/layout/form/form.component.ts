import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { HttpClient } from '@angular/common/http';
import html2canvas from 'html2canvas';



@Component({
    selector: 'app-form',
    templateUrl: './form.component.html',
    styleUrls: ['./form.component.scss'],
    animations: [routerTransition()]
})
export class FormComponent implements OnInit {

  cropList: string[] = ['Wheat', 'Corn', 'Rice', 'Barley', 'Soybean', 'Cotton', 'Sugarcane', 'Tomato', 'Potato', 'Sunflower'];
  areaList: string[] = [
    'Albania', 'Algeria', 'Angola', 'Argentina', 'Armenia', 'Australia', 'Austria', 
    'Azerbaijan', 'Bahamas', 'Bahrain', 'Bangladesh', 'Belarus', 'Belgium', 'Botswana', 
    'Brazil', 'Bulgaria', 'Burkina Faso', 'Burundi', 'Cameroon', 'Canada', 
    'Central African Republic', 'Chile', 'Colombia', 'Croatia', 'Denmark', 
    'Dominican Republic', 'Ecuador', 'Egypt', 'El Salvador', 'Eritrea', 'Estonia', 
    'Finland', 'France', 'Germany', 'Ghana', 'Greece', 'Guatemala', 'Guinea', 
    'Guyana', 'Haiti', 'Honduras', 'Hungary', 'India', 'Indonesia', 'Iraq', 
    'Ireland', 'Italy', 'Jamaica', 'Japan', 'Kazakhstan', 'Kenya', 'Latvia', 
    'Lebanon', 'Lesotho', 'Libya', 'Lithuania', 'Madagascar', 'Malawi', 'Malaysia', 
    'Mali', 'Mauritania', 'Mauritius', 'Mexico', 'Montenegro', 'Morocco', 'Mozambique', 
    'Namibia', 'Nepal', 'Netherlands', 'New Zealand', 'Nicaragua', 'Niger', 'Norway', 
    'Pakistan', 'Papua New Guinea', 'Peru', 'Poland', 'Portugal', 'Qatar', 'Romania', 
    'Rwanda', 'Saudi Arabia', 'Senegal', 'Slovenia', 'South Africa', 'Spain', 
    'Sri Lanka', 'Sudan', 'Suriname', 'Sweden', 'Switzerland', 'Tajikistan', 'Thailand', 
    'Tunisia', 'Turkey', 'Uganda', 'Ukraine', 'United Kingdom', 'Uruguay', 'Zambia', 
    'Zimbabwe'
  ];

  soilTypeList: string[] = ['Loamy', 'Sandy', 'Clay'];

  // isValidArea(): boolean {
  //   return this.areaList.includes(this.formData.area);
  // }

    constructor(private http: HttpClient) {}

    ngOnInit() {}

    formData = {
        crop: '',
        soil: '',
        soilPh: '',
        temperature: '',
        humidity: '',
        windSpeed: '',
        soilQuality: '',
        n: '',
        p: '',
        k: '',
        date: '',
      };
    
      predictedYield: number = 0;
      showModal: boolean = false;
      showConvert: boolean = false;
      convertedYield1 : number = 0;
      convertedYield2 : number = 0;



getPredictedYield() {
  const body = {
    Crop_Type: this.formData.crop,
    Soil_Type: this.formData.soil,
    Soil_pH: this.formData.soilPh,
    Temperature: this.formData.temperature,
    Humidity: this.formData.humidity,
    Wind_Speed: this.formData.windSpeed,
    N: this.formData.n,
    P: this.formData.p,
    K: this.formData.k,
    Soil_Quality: this.formData.soilQuality
  };

  this.http.post<{ predicted_crop_yield: number }>('http://localhost:5000/predict', body)
    .subscribe({
      next: res => {
        this.predictedYield = res.predicted_crop_yield;
        this.showModal = true;
      },
      error: err => {
        console.error(err);
      }
    });
}


      convertedYield = this.predictedYield;
      selectedUnit = 'hg/ha'; 
    
      convertYield() {
        this.showConvert = true;
          this.convertedYield = this.predictedYield 
          this.convertedYield1 = this.predictedYield / 1000; // Convert to t/ha
          this.convertedYield2 = this.predictedYield * 10; // Reset to hg/ha
        
      }

      async downloadAsPNG() {
        console.log('Downloading as PNG');
        const captureElement = document.getElementById('capture');
        if (captureElement) {
          const canvas = await html2canvas(captureElement);
          const image = canvas.toDataURL('image/png');
    
          // Create a download link
          const link = document.createElement('a');
          link.href = image;
          link.download = 'Crop_Yield_Prediction.png';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
      }
    
      closeModal() {
        this.showModal = false;
      }

      closeModal2() {
        this.showConvert = false;
      }
}
