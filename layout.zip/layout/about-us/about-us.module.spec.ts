import { AboutUsModule } from './about-us.module';

describe('BsElementModule', () => {
    let aboutUsModule: AboutUsModule;

    beforeEach(() => {
        aboutUsModule = new AboutUsModule();
    });

    it('should create an instance', () => {
        expect(aboutUsModule).toBeTruthy();
    });
});
