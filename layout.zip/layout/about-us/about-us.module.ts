import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PageHeaderModule } from '../../shared';

import { AbotUsRoutingModule } from './about-us-routing.module';
import { AboutUsComponent } from './about-us.component';
import { FormsModule } from '@angular/forms';

@NgModule({
    imports: [CommonModule, AbotUsRoutingModule, PageHeaderModule, NgbModule, FormsModule],
    declarations: [AboutUsComponent]
})
export class AboutUsModule {}
