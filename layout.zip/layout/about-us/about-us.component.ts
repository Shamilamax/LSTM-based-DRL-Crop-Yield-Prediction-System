import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import emailjs from '@emailjs/browser';


@Component({
    selector: 'app-about-us',
    templateUrl: './about-us.component.html',
    styleUrls: ['./about-us.component.scss'],
    animations: [routerTransition()]
})
export class AboutUsComponent implements OnInit {
    constructor() {}

    ngOnInit() {}

    
      userFeedback = { name: '', email: '', message: '' };
      feedbackSent = false;
    
      sendFeedback() {
        emailjs.send('service_6jufs7r', 'template_kgejh3g', this.userFeedback, 'm6M52XmP4JQkdrX_A')
          .then(() => {
            this.feedbackSent = true;
            this.userFeedback = { name: '', email: '', message: '' }; 
          })
          .catch(error => console.error('Error sending email:', error));
      }
}
