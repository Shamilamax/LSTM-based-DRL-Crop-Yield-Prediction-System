import { Component, OnInit } from '@angular/core';
import { BlankPageService } from './blank-page.service';

@Component({
    selector: 'app-blank-page',
    templateUrl: './blank-page.component.html',
    styleUrls: ['./blank-page.component.scss']
})
export class BlankPageComponent implements OnInit {
    newsArticles: any[] = [];

    constructor(private newsService: BlankPageService) {}
  
    ngOnInit(): void {
      this.newsService.getAgriculturalNews().subscribe((data: any) => {
        this.newsArticles = data.articles;
      });
    }
}
