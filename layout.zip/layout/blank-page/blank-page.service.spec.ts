import { TestBed } from '@angular/core/testing';

import { BlankPageService } from './blank-page.service';

describe('BlankPageService', () => {
  let service: BlankPageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BlankPageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
