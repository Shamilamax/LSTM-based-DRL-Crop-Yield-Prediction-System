import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BlankPageService {

  private apiKey = 'a3908ba95a124da5af36af9999ab74bf'; 
  private apiUrl = 'https://newsapi.org/v2/everything';

  constructor(private http: HttpClient) {}

  getAgriculturalNews(): Observable<any> {
    const query = 'Farming food production';
    const url = `${this.apiUrl}?q=${query}&apiKey=${this.apiKey}`;
    return this.http.get(url);
  }
}
