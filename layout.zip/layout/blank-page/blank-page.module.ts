import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { BlankPageRoutingModule } from './blank-page-routing.module';
import { BlankPageComponent } from './blank-page.component';

import { HttpClientModule } from '@angular/common/http';


@NgModule({
    imports: [CommonModule, BlankPageRoutingModule, HttpClientModule],
    declarations: [BlankPageComponent]
})
export class BlankPageModule {}
